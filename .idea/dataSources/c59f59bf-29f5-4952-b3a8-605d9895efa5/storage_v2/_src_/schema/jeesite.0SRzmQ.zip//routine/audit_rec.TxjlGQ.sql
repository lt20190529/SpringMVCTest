CREATE PROCEDURE audit_rec(IN rid VARCHAR(64), IN audituser VARCHAR(64), OUT msg VARCHAR(255))
  leave_name:BEGIN
	-- "06741bc2f65540e6b196e41cb1d05f33",6,@msg
  DECLARE flag VARCHAR(64);   -- 审核标志
	DECLARE t_depid VARCHAR(64);   -- 项目id 
	DECLARE t_itemid  VARCHAR(64);   -- 部门id
  DECLARE tuom VARCHAR(10);       -- 单位  
	DECLARE tqty    int(100);       -- 数量
	DECLARE cnt int(10);
  

  declare done int default 0;
  declare recdetail CURSOR for select item_dr,qty,uom from erp_recdetail where recid=rid;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

  select audit_Flag into flag from erp_rec where id=rid;
  if flag="Y" THEN
    set msg="Y";
    LEAVE leave_name;
  
  ELSE 
      
      START TRANSACTION;
			open recdetail;
				 
				 repeat
				 fetch recdetail into t_itemid,tqty,tuom;
				 -- select t_itemid,tqty,tuom;

				 select dep into t_depid from erp_rec where id=rid;
				 IF NOT done THEN
					 -- 有则update
					 if EXISTS (select * from erp_dep_stock where dep_dr=t_depid and item_dr=t_itemid) then
								update erp_dep_stock set qty=qty + tqty where dep_dr=t_depid and item_dr=t_itemid;  
					 ELSE  -- 无则insert
							 INSERT INTO erp_dep_stock (dep_dr,item_dr,qty,uom_dr) VALUES (t_depid,t_itemid,tqty,tuom);  
					 end if;
				 END IF;
				 until done  end repeat;

			close recdetail;
		
			-- 更新审核标识
			UPDATE erp_rec set audit_by=audituser,audit_date=now(),audit_flag='Y' WHERE id=rid;
			
			COMMIT;

      set msg="N";
      
  end if;  
END;

